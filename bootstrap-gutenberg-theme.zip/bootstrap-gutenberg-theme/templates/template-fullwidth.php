<?php
/*
Template Name: Fullwidth Template
*/
get_header(); ?>
<div class="row">
    <div class="col-12">
        <?php
        while (have_posts()) : the_post();
            the_content();
        endwhile;
        ?>
    </div>
</div>
<?php get_footer(); ?>
