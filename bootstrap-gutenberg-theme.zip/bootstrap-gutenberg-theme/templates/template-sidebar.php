<?php
/*
Template Name: Sidebar Template
*/
get_header(); ?>
<div class="row">
    <div class="col-md-8">
        <?php
        while (have_posts()) : the_post();
            the_content();
        endwhile;
        ?>
    </div>
    <?php get_sidebar(); ?>
</div>
<?php get_footer(); ?>
