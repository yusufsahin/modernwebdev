<?php get_header(); ?>
<h1>Archive</h1>
<?php get_footer(); ?>