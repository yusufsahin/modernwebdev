jQuery(document).ready(function ($) {
    console.log("Custom JavaScript loaded.");
});