<?php
require_once get_template_directory() . '/inc/class-wp-bootstrap-navwalker.php';


function bootstrap_gutenberg_enqueue_assets() {
    wp_enqueue_style('bootstrap-css', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css', [], '5.3.3');
    wp_enqueue_style('theme-style', get_stylesheet_uri());
    wp_enqueue_script('bootstrap-js', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js', ['jquery'], '5.3.3', true);
    wp_enqueue_script('custom-js', get_template_directory_uri() . '/assets/js/custom.js', ['jquery'], '1.0', true);
}
add_action('wp_enqueue_scripts', 'bootstrap_gutenberg_enqueue_assets');

function bootstrap_gutenberg_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('align-wide');
    add_theme_support('editor-styles');
    add_editor_style('assets/css/editor-style.css');

    // Register navigation menus
    register_nav_menus([
        'primary' => __('Primary Menu', 'bootstrap-gutenberg'),
        'footer' => __('Footer Menu', 'bootstrap-gutenberg'),
    ]);
}
add_action('after_setup_theme', 'bootstrap_gutenberg_setup');
?>