<?php get_header(); ?>
<h1>Search Results</h1>
<?php get_footer(); ?>