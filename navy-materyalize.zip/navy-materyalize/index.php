<?php get_header(); ?>
<main class="site-main">
    <div class="container">
        <div class="row">
            <!-- Main Content Area -->
            <div class="col s12 m12">
                <?php if (have_posts()) : ?>
                    <?php while (have_posts()) : the_post(); ?>
                        <div class="card">
                            <div class="card-content">
                                <h2 class="card-title"><?php the_title(); ?></h2>
                                <div class="card-text">
                                    <?php the_content(); ?>
                                </div>
                            </div>
                        </div>
                    <?php endwhile; ?>
                <?php else : ?>
                    <div class="no-posts">
                        <p>No posts found. Please add some content.</p>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Sidebar Area 
            <div class="col s12 m4">
                <?php get_sidebar(); ?>
            </div>-->
        </div>
    </div>
</main>
<?php get_footer(); ?>
