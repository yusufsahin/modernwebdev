<?php
/**
 * Theme Setup
 */
function navy_theme_setup() {
    // Theme support features
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('custom-logo');
    add_theme_support('html5', ['search-form', 'comment-form', 'gallery', 'caption']);

    // Register menus
    register_nav_menus([
        'primary' => __('Primary Menu', 'navy-theme'),
        'footer'  => __('Footer Menu', 'navy-theme'),
    ]);
}
add_action('after_setup_theme', 'navy_theme_setup');

/**
 * Enqueue Styles and Scripts
 */
function navy_enqueue_assets() {
    // Materialize CSS
    wp_enqueue_style(
        'materialize-css',
        'https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css',
        [],
        '1.0'
    );

    // Theme main stylesheet
    wp_enqueue_style(
        'navy-main',
        get_template_directory_uri() . '/assets/css/main.css',
        [],
        filemtime(get_template_directory() . '/assets/css/main.css') // Versioning for cache-busting
    );

    // Materialize JS
    wp_enqueue_script(
        'materialize-js',
        'https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js',
        ['jquery'],
        '1.0',
        true
    );

    // Theme main JavaScript
    wp_enqueue_script(
        'navy-main',
        get_template_directory_uri() . '/assets/js/main.js',
        [],
        filemtime(get_template_directory() . '/assets/js/main.js'), // Versioning for cache-busting
        true
    );
}
add_action('wp_enqueue_scripts', 'navy_enqueue_assets');

/**
 * Default Fallback Menu
 */
function navy_default_menu() {
    echo '<ul class="right hide-on-med-and-down">';
    $pages = get_pages();

    if (!empty($pages)) {
        foreach ($pages as $page) {
            $link = get_page_link($page->ID);
            echo '<li><a href="' . esc_url($link) . '">' . esc_html($page->post_title) . '</a></li>';
        }
    } else {
        echo '<li><a href="' . esc_url(home_url()) . '">Home</a></li>';
        echo '<li><a href="' . esc_url(home_url('/about')) . '">About</a></li>';
        echo '<li><a href="' . esc_url(home_url('/contact')) . '">Contact</a></li>';
    }
    echo '</ul>';
}

function navy_gutenberg_support() {
    // Blok genişliği ayarı
    add_theme_support('align-wide');

    // Özel renk paleti tanımlama
    add_theme_support('editor-color-palette', [
        [
            'name'  => __('Midnight Blue', 'navy-theme'),
            'slug'  => 'midnight-blue',
            'color' => '#2C3E50',
        ],
        [
            'name'  => __('Teal', 'navy-theme'),
            'slug'  => 'teal',
            'color' => '#1ABC9C',
        ],
        [
            'name'  => __('Mustard Yellow', 'navy-theme'),
            'slug'  => 'mustard-yellow',
            'color' => '#F39C12',
        ],
        [
            'name'  => __('Soft Gray', 'navy-theme'),
            'slug'  => 'soft-gray',
            'color' => '#ECF0F1',
        ],
        [
            'name'  => __('Charcoal Gray', 'navy-theme'),
            'slug'  => 'charcoal-gray',
            'color' => '#34495E',
        ],
    ]);

    // Özel yazı tipleri
    add_theme_support('editor-font-sizes', [
        [
            'name' => __('Small', 'navy-theme'),
            'size' => 12,
            'slug' => 'small',
        ],
        [
            'name' => __('Normal', 'navy-theme'),
            'size' => 16,
            'slug' => 'normal',
        ],
        [
            'name' => __('Large', 'navy-theme'),
            'size' => 36,
            'slug' => 'large',
        ],
        [
            'name' => __('Huge', 'navy-theme'),
            'size' => 50,
            'slug' => 'huge',
        ],
    ]);

    // Varsayılan Gutenberg stili devre dışı bırakılabilir
    add_theme_support('editor-styles');
    add_editor_style('assets/css/editor-styles.css'); // Özel editör stili ekleme
}
add_action('after_setup_theme', 'navy_gutenberg_support');

function navy_block_editor_settings() {
    add_theme_support('responsive-embeds'); // Responsive videolar
    add_theme_support('custom-spacing');   // Blok aralıkları
    add_theme_support('custom-line-height'); // Satır yüksekliği
}
add_action('after_setup_theme', 'navy_block_editor_settings');

?>
