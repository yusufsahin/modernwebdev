<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<header>
    <nav class="nav-wrapper navy-blue">
        <div class="container">
            <a href="<?php echo home_url(); ?>" class="brand-logo"><?php bloginfo('name'); ?></a>
            <a href="#" data-target="mobile-nav" class="sidenav-trigger"><i class="material-icons">menu</i></a>
            <?php wp_nav_menu([
                'theme_location' => 'primary',
                'menu_class' => 'right hide-on-med-and-down',
                'container' => false,
                'fallback_cb' => 'navy_default_menu',
            ]); ?>
        </div>
    </nav>
    <ul class="sidenav" id="mobile-nav">
        <?php wp_nav_menu([
            'theme_location' => 'primary',
            'items_wrap' => '%3$s',
            'fallback_cb' => 'navy_default_menu',
        ]); ?>
    </ul>
</header>
