# WordPress Theme
This is a fully responsive WordPress theme using Materialize CSS and Navy color palette.